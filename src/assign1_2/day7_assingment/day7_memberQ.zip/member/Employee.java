package day7_assingment.member;

public class Employee extends Member {

	String specialisation;
	String department;
}
