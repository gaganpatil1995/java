package day7_assingment.member;

public class Member {

	String name ;
	int age ;
	String phoneNumber;
	String address ;
	double salary;
	void printSalary() {
		System.out.println("Salary :" + salary);
	}
	
	public static void main(String[] args) {
		
	}
}
