package day7_assingment.member;

public class Manager extends Member {
  
	String specialisation;
	String department;
}
